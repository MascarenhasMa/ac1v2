package com.ac1final.ac1final.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ac1final.ac1final.models.Categoria;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Repository
public class CategoriaRepository {
    @Autowired
    private EntityManager entityManager;

    @Transactional
    public Categoria salvar(Categoria categoria){
        categoria = entityManager.merge(categoria);
        return categoria;
    }

    public List<Categoria> obterTodos(){
        return entityManager.createQuery("SELECT c FROM Categoria c", Categoria.class).getResultList();
    }
    
}
