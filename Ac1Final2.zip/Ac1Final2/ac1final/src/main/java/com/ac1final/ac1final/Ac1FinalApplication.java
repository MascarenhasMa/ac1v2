package com.ac1final.ac1final;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.ac1final.models.Categoria;
import com.example.ac1final.models.Produto;
import com.example.ac1final.repositories.CategoriaRepository;
import com.example.ac1final.repositories.ProdutoRepository;

@SpringBootApplication
public class Ac1finalApplication {

	@Bean
	public CommandLineRunner init(
			@Autowired ProdutoRepository produtoRepository,
			@Autowired CategoriaRepository categoriaRepository) {
		return args -> {
			System.out.println("*** CRIANDO AS CATEGORIAS ***");
			Categoria c1 = categoriaRepository.salvar(new Categoria(0L, "Alimento"));
			Categoria c2 = categoriaRepository.salvar(new Categoria(0L, "Limpeza"));
			
			List<Categoria> listaCategoria = categoriaRepository.obterTodos();
			listaCategoria.forEach(System.out::println);

			System.out.println("*** CRIANDO OS PRODUTOS ***");
			produtoRepository.salvar(
					new Produto(0L, "pão", 10.50));
			produtoRepository.salvar(
					new Produto(0L, "Detergente", 25.50));
					produtoRepository.salvar(
					new Produto(0L, "TV", 1220.0));
					produtoRepository.salvar(
					new Produto(0L, "Notebook", 350.0));
			List<Produto> listaProduto = produtoRepository.obterTodos();
			listaProduto.forEach(System.out::println);

			System.out.println("* PRODUTOS COM PREÇO MAIOR QUE 150.00 *");
			List<Produto> lista = ProdutoRepository.findByPrecoGreaterThan(150.00);
			lista.forEach(System.out::println);
	
			System.out.println("* PRODUTOS COM PREÇO MENOR QUE 150.00 *");
			List<Produto> listama = ProdutoRepository.findByPrecoLessThanEqual(150.00);
			listama.forEach(System.out::println);
	
			System.out.println("* PRODUTOS COMEÇA COM 'D' *");
			List<Produto> listame = ProdutoRepository.findByNomeStartingWith("D");
			listame.forEach(System.out::println);
		};
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ac1finalApplication.class, args);
	}

}
