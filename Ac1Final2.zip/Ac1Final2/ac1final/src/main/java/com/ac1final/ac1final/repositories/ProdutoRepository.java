package com.ac1final.ac1final.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ac1final.ac1final.models.Produto;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Repository
public class ProdutoRepository {
    @Autowired
    private EntityManager entityManager;

    @Transactional
    public Produto salvar(Produto produto) {
        produto = entityManager.merge(produto);
        return produto;
    }

    public List<Produto> obterTodos() {
        return entityManager
                .createQuery("from Produto", Produto.class).getResultList();
    }

    @Transactional
    public void excluir(Produto produto) {
        entityManager.remove(produto);
    }


    //Um método de consulta que retorne todos os produtos com preço maior do que um determinado valor. Este método deve receber um parâmetro do tipo Double chamado valor e retornar uma lista de produtos com preço maior do que o valor informado.
    public interface ProdutoRepository extends JpaRepository<Produto, Long> {
        List<Produto> findByPrecoGreaterThan(Double preco);

    // Um método de consulta que retorne todos os produtos com preço menor ou igual do que um determinado valor. Este método deve receber um parâmetro do tipo Double chamado valor e retornar uma lista de produtos com preço seja menor ou igual ao valor informado
        List<Produto> findByPrecoLessThanEqual(Double preco);

        // Um método de consulta que retorne todos os produtos que começam com um determinado nome. Este método deve receber um parâmetro do tipo String chamado nome e retornar uma lista de produtos em que o nome começa com o nome informado
        List<Produto> indByNomeStartingWith(String nome);

    }
    

    
}