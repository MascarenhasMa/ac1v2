package com.ac1final.ac1final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ac1finalApplicationTests {

	@Test
	void contextLoads() {
	}

}
